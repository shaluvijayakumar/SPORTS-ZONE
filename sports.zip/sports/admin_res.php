<?php
include 'admin_das.php';
?>
<?php
$ik = $_SESSION["ig"];
?>

<div class="main">
    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="card">
                    <form method="post" enctype="multipart/form-data" style="padding:25px;">
                        <div class="mb-3 mt-3">
                            <?php
                            print("<input type='text' value='$ik' class='form-control' name='vc'>");
                            ?>
                        </div>
                        <div class="mb-3">

                            <select id="hov" class="form-select" name="dep" required style="box-shadow:blue 1px 1px 2px 2px">
                                <option selected disabled value=""> Select Wining Department</option>
                                <option value="CS">CS</option>
                                <option value="IT">IT & BCA</option>
                                <option value="BCOM">BCOM</option>
                                <option value="BBA">BBA</option>
                                <option value="BCOM CA">BCOM CA</option>
                                <option value="TAMIL">TAMIL</option>
                                <option value="ENGLISH">ENGLISH</option>
                                <option value="CDF">CDF</option>
                                <option value="MATHS">MATHS</option>
                            </select>
                        </div>
                        <input type="submit" value="Update" name="sub" style=" margin-left:20px">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
if (isset($_POST["sub"])) {
    $vcid = $_POST["vc"];
    $dep = $_POST["dep"];

    $con = mysqli_connect("localhost", "root", "", "sports");
    if ($con) {
        $q = "update  time_table  set status='update',result='$dep'where id='$vcid'";
        $sql = mysqli_query($con, $q);
        print("<script> alert(' result update');</script>");
    }
}
?>