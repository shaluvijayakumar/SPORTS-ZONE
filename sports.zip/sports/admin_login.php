<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body">
    <header>
        <div class="container-fluid" style=" background-color: #008cba;">
            <div class=" row">
                <div class="col-md-3">
                </div>
                <div class="col-md-9">
                    <h1 style="padding-top:30px; padding-left:200px;  color:orange;">KASC SPORTS</h1>
                </div>
            </div>
        </div>

    </header>








    <div class="container">

        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-4">
                <div class="card" style="margin-top: 100px; width:500px;height:300px;">
                    <div class="container">
                        <h1 align="center" style="color:black;">ADMIN LOGIN</h1>
                        <form method="post" enctype="multipart/form-data" style="padding:10px;">

                            <div class="mb-3">

                                <input type="text" class="form-control" placeholder="Enter admin ID" name="user" require style="width:450px;height:50px;box-shadow:blue 1px 1px 2px 2px">
                            </div>

                            <div class="mb-3" style="margin-top: 40px;">

                                <input type="password" class="form-control" placeholder="Enter Password" name="pass" require style="width:450px;height:50px;box-shadow:blue 1px 1px 2px 2px">
                            </div>
                            <input type="submit" value="LOGIN" name="sub" class="btn btn-success" style="background-color: green; margin-left:20px;color:white; margin-top:20px;">
                            <a href="./homepage.php"> <input type="button" class="btn btn-danger" value="BACK" style="background-color: red; margin-left:180px;color:white;margin-top:20px;"></a>
                        </form>
                    </div>

                </div>
                <div class="col-md-4"></div>
            </div>
        </div>

        </body>

</html>

<?php
if (isset($_POST["sub"])) {
    $use = $_POST["user"];
    $pas = $_POST["pass"];

    if ($use == "admin" && $pas == "1234") {
        print("<script> alert('login success'); document.location='admin_das.php';</script>");
        return true;
    } else {
        print("<script> alert ('ENTER VALID ADMINID AND PASSWORD');</script>");
        return false;
    }
}

?>