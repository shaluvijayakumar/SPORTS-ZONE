<?php
include 'admin_das.php';
?>

<body class="main">
    <div class="container">
        <div class="row">
            <div class="col-md-4"> </div>
            <div class="col-md-5">
                <div class="card" style="margin-top:40px;">
                    <div class="cantainer">
                        <h3 align="center" style="color: red;"> TIME TABLE FORM</h3>
                        <form method="post" enctype="multipart/form-data" style="padding:25px;">


                            <div class="mb-3">
                                <label class="form-label">DATE</label>
                                <input type="date" class="form-control" name="Date" required style="box-shadow:blue 1px 1px 2px 2px">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">TIME</label>
                                <input type="text" class="form-control" name="time" required style="box-shadow:blue 1px 1px 2px 2px">
                            </div>

                            <div class="mb-3">

                                <select id="hov" class="form-select" name="game" required style="box-shadow:blue 1px 1px 2px 2px">
                                    <option selected disabled value=""> Select Game</option>
                                    <option value="Running">Running</option>
                                    <option value="Volleyball">Volleyball</option>
                                    <option value="Football">Football</option>
                                    <option value="Tennis">Tennis</option>
                                    <option value="Cricket">Cricket</option>
                                    <option value="Kabaddi">Kabaddi</option>
                                    <option value="Kho Kho">Kho Kho</option>
                                </select>
                            </div>

                            <div class="mb-3">

                                <select id="ho" class="form-select" name="gen" required style="box-shadow:blue 1px 1px 2px 2px">
                                    <option selected disabled value=""> SELECT YOUR GENDER</option>
                                    <option value="male">MALE</option>
                                    <option value="female">FEMALE</option>
                                </select>
                            </div>

                            <div class="mb-3">

                                <select id="hov" class="form-select" name="dep1" required style="box-shadow:blue 1px 1px 2px 2px">
                                    <option selected disabled value=""> Select First Department</option>
                                    <option value="CS">CS</option>
                                    <option value="IT">IT & BCA</option>
                                    <option value="BCOM">BCOM</option>
                                    <option value="BBA">BBA</option>
                                    <option value="BCOM CA">BCOM CA</option>
                                    <option value="TAMIL">TAMIL</option>
                                    <option value="ENGLISH">ENGLISH</option>
                                    <option value="CDF">CDF</option>
                                    <option value="MATHS">MATHS</option>
                                </select>
                            </div>

                            <div class="mb-3">

                                <select id="hov" class="form-select" name="dep2" required style="box-shadow:blue 1px 1px 2px 2px">
                                    <option selected disabled value=""> Select Next Department</option>
                                    <option value="CS">CS</option>
                                    <option value="IT">IT & BCA</option>
                                    <option value="BCOM">BCOM</option>
                                    <option value="BBA">BBA</option>
                                    <option value="BCOM CA">BCOM CA</option>
                                    <option value="TAMIL">TAMIL</option>
                                    <option value="ENGLISH">ENGLISH</option>
                                    <option value="CDF">CDF</option>
                                    <option value="MATHS">MATHS</option>
                                </select>
                            </div>

                            <div class="mb-3">

                                <select id="hov" class="form-select" name="type" required style="box-shadow:blue 1px 1px 2px 2px">
                                    <option selected disabled value=""> Select TYPE</option>
                                    <option value="1st Round">1st Round</option>
                                    <option value="2st Round">2st Round</option>
                                    <option value="Semi final">Semi-Final</option>
                                    <option value="Final">Final</option>
                                </select>
                            </div>


                            <div class="mb-3">
                                <input type="submit" value="ADD" name="sub" class='btn btn-' style="background-color: orange;  margin-left:20px">
                                <a href="admin das.php"> <input type="button" value="BACK" class='btn btn-danger' style="background-color: red; margin-left:  120px;"></a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <?php

    if (isset($_POST["sub"])) {
        $dat = $_POST["Date"];
        $tim = $_POST["time"];
        $game = $_POST["game"];
        $gender = $_POST["gen"];
        $dp1 = $_POST["dep1"];
        $dp2 = $_POST["dep2"];
        $typ = $_POST["type"];
        $sta = 'new';
        $re = '';

        $con = mysqli_connect("localhost", "root", "", "sports");

        if ($con) {
            $q = "insert into time_table(date,time,game,gender,department1,department2,type,status,result)values('$dat','$tim','$game','$gender','$dp1','$dp2','$typ','$sta','$re')";
            $sq = mysqli_query($con, $q);
            print("<script> alert('data inserted');</script>");
        }
    }
    ?>


</body>

</html>