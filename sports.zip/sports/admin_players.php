<?php
include 'admin_das.php';
?>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <center>
                <h1> PLAYER DETAILS </h1>
            </center>
            <?php
            $con = mysqli_connect("localhost", "root", "", "sports");
            if ($con) {
                $q = "select * from player_details where status='approve'";
                $sql = mysqli_query($con, $q);
                print("<center> <table border=3px; cellpadding=10px>
                        <tr>
                        <th>Id</th>
                            <th>Name</th>
                            <th>Roll Number</th>
                            <th>Department</th>
                            <th>Gender</th>
                            <th>game</th>
                            
                            </tr>");
                while ($row = mysqli_fetch_row($sql)) {
                    $id = $row[0];

                    print("<form method='post'>
                        <tr>
                         <td>$row[0]</td>
                        <td>$row[1]</td>
                        <td>$row[2]</td>
                        <td>$row[4]</td>
                        <td>$row[3]</td>
                        <td>$row[6]</td> 
                        </tr><br> </form>");
                }
                print("</table></center>");
            }

            ?>
        </div>
    </div>
</div>